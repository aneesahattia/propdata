<?php
$config = array(
  'accountid' => '1372545',
  'mediadb' => './.cm4all/mediadb/',
  'listingkey' => 'YATC5APRCQAO7TGIIWVQ',
  'hosting-backend-server' => 'hstbe-sites.dedicated.co.za',
  'maxiprocfilesize' => '10000000',
  'maxiprocimagesize' => '5000'
);
?>
