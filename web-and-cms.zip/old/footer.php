<div class="container_12">

				<div class="grid_12">

					
						<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_GB/sdk.js#xfbml=1&version=v2.8&appId=1893089717628336";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));</script>
<div style="text-align:center !important;">
<div class="fb-page" data-href="https://www.facebook.com/HETTRAVELANDTOURS" data-tabs="timeline" data-width="500" data-height="500" data-small-header="false" data-adapt-container-width="true" data-hide-cover="false" data-show-facepile="true"><blockquote cite="https://www.facebook.com/HETTRAVELANDTOURS" class="fb-xfbml-parse-ignore"><a href="https://www.facebook.com/HETTRAVELANDTOURS">H.E.T Travel and Tours&quot;&quot;</a></blockquote></div>

					</div>

				</div>
<div class="grid_12">
				<div class="copy">

						Het tRAVELS (c) 2014 || Website  Designed by aneesa hattia</div>
</div>
				</div>

			</div>