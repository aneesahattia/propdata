<li><a href="index.php">ABOUT</a></li>
								<li><a href="index-1.php">HOT TOURS</a></li>
								<li><a href="index-2.php">SPECIAL OFFERS</a></li>
                                <li><a href="index-3.php">BOOKING TOOLS</a></li>
                                  <li><a href="index-5.php">LOUNGE PASS</a></li>
                                  <li class="current"><a href="index-6.php">FLIGHTS</a></li>
								<li><a href="index-4.php">CONTACTS</a></li>