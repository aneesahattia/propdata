<?php
$con = mysqli_connect("localhost","hettrcei_admin","uhUfDub8","hettrcei_cms","3306");

// Check connection
if (mysqli_connect_errno())
{
echo "Failed to connect to MySQL: " . mysqli_connect_error();
} else
{
echo "Successfully connected to DB";
}
?>
